document.addEventListener("DOMContentLoaded", function () {
    // View Tickets action
    document.getElementById("view-tickets").addEventListener("click", function () {
        alert("Redirecting to ticket page...");
    });

    // Contact Organizer action
    document.getElementById("contact-organizer").addEventListener("click", function () {
        alert("Redirecting to contact organizer form...");
    });
});
